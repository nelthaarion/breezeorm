package benchmark

import (
	"database/sql"
	"fmt"
	"path/filepath"
	"testing"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

// newSQLiteFile creates a fresh SQLite file for one library under the
// benchmark's temp dir, so each library gets its own file/connection and
// none of them contend with each other.
func newSQLiteFile(b *testing.B, name string) string {
	b.Helper()
	dir := b.TempDir()
	return filepath.Join(dir, name+".db")
}

// rawOpen opens a *sql.DB against path via the shared mattn/go-sqlite3
// driver (every library in this benchmark uses the same driver — Bun and
// sqlx both accept a *sql.DB directly, and GORM's sqlite driver wraps the
// same underlying package), applies the schema, and pins the pool to a
// single connection: SQLite serializes writers regardless, and a single
// connection avoids spurious "database is locked" errors from this
// benchmark's sequential access pattern.
func rawOpen(b *testing.B, path string) *sql.DB {
	b.Helper()
	db, err := sql.Open("sqlite3", path+"?_journal_mode=WAL&_busy_timeout=5000")
	if err != nil {
		b.Fatalf("open %s: %v", path, err)
	}
	db.SetMaxOpenConns(1)
	if _, err := db.Exec(schemaSQL); err != nil {
		b.Fatalf("apply schema: %v", err)
	}
	return db
}

// seedRows inserts n rows directly via database/sql (bypassing every ORM
// under test) so seed cost is identical and never counted against any
// library's benchmark numbers.
func seedRows(b *testing.B, db *sql.DB, n int) {
	b.Helper()
	tx, err := db.Begin()
	if err != nil {
		b.Fatalf("begin seed tx: %v", err)
	}
	stmt, err := tx.Prepare(`INSERT INTO bench_users (email, name, active, created_at) VALUES (?, ?, ?, ?)`)
	if err != nil {
		b.Fatalf("prepare seed stmt: %v", err)
	}
	now := time.Now().UTC()
	for i := 0; i < n; i++ {
		active := i%2 == 0
		if _, err := stmt.Exec(fmt.Sprintf("user%d@example.com", i), fmt.Sprintf("User %d", i), active, now); err != nil {
			b.Fatalf("seed row %d: %v", i, err)
		}
	}
	stmt.Close()
	if err := tx.Commit(); err != nil {
		b.Fatalf("commit seed tx: %v", err)
	}
}

// seedRowCount is the fixed dataset size used for all read/update
// benchmarks, chosen to be large enough that an index scan and a full
// table scan behave differently, small enough to seed quickly per benchmark.
const seedRowCount = 10000
