# breezeorm vs GORM vs Bun vs sqlx vs database/sql

Real benchmarks, run in this sandbox, against real dependencies (not
simulated) — GORM, Bun, sqlx, and mattn/go-sqlite3 were actually fetched and
executed, not mocked. SQLite via the shared `mattn/go-sqlite3` (cgo) driver
so every library talks to the same driver/storage engine and only ORM
overhead differs.

## Run it yourself

```bash
cd benchmark
go test -run NONE -bench . -benchmem -benchtime=2s .
```

`go.mod` uses `replace` directives to fetch GORM/Bun from their GitHub
mirrors directly (this sandbox's network egress allowlist doesn't include
`gorm.io` / other vanity import domains, only `github.com`) — see the
`replace` block in `go.mod` if you're reproducing this outside a similarly
locked-down network; on a normal machine `go get gorm.io/gorm` etc. works
without any of that.

## Methodology

- **Dataset**: 10,000 seeded rows per benchmark (seeded via raw `database/sql`
  outside any ORM, so seed cost is never counted).
- **Isolation**: each library gets its own SQLite file and connection
  (`SetMaxOpenConns(1)`), so none of them contend with each other.
- **Fairness**: GORM is configured with `PrepareStmt: true` (its own
  statement cache) since breezeorm caches prepared statements by default —
  comparing "breezeorm with caching on" against "GORM with caching off" would
  just measure who forgot to flip a config flag, not ORM overhead.
  `raw_sql_prepared` prepares its statement once, outside the timed loop —
  it is the fastest-possible baseline every library is bounded by.
- **Noise check**: `BenchmarkFindByID` and `BenchmarkSelectWhereLimit` were
  run 3x independently (`-count=3`) to confirm the breezeorm-vs-others gap is a
  real, reproducible signal and not sandbox scheduling noise — run-to-run
  variance was ~2-3% for every library, well below the ~30-50% gap being
  reported. Raw output for all runs is in this directory
  (`results_raw.txt`, `results_before_compiled_cache.txt`,
  `results_3x_findbyid_selectlimit.txt`).
- **What's NOT measured**: network-attached Postgres/MySQL latency (SQLite
  is in-process, so these numbers isolate ORM/driver overhead from network
  RTT), concurrent/parallel load, joins, or preloading.

## Results (2s benchtime, Go 1.23.4, linux/amd64, Intel Xeon @ 2.10GHz)

| Operation | raw_sql (prepared) | **breezeorm** | GORM | Bun | sqlx |
|---|---:|---:|---:|---:|---:|
| Insert | 67.7 µs / 10 allocs | **124.6 µs / 40 allocs** | 132.4 µs / 105 allocs | 110.8 µs / 26 allocs | 78.9 µs / 12 allocs |
| FindByID | 4.5 µs / 18 allocs | **16.6 µs / 54 allocs** | 11.0 µs / 58 allocs | 14.8 µs / 41 allocs | 10.6 µs / 40 allocs |
| SelectWhereLimit(50) | 83.9 µs / 366 allocs | **214.4 µs / 600 allocs** | 133.8 µs / 700 allocs | 109.8 µs / 393 allocs | 108.9 µs / 439 allocs |
| Update | 10.1 µs / 31 allocs | **10.1 µs / 31 allocs** | 26.4 µs / 83 allocs | 16.5 µs / 14 allocs | 13.9 µs / 8 allocs |

(FindByID/SelectWhereLimit are the median of 3 independent runs; Insert/Update
are a single 2s run — see the raw result files for full distributions.)

## Honest read of these numbers

**breezeorm wins or ties on Insert and Update** against GORM, and is competitive
with Bun on Update. Its statement-level caching (`Executor`'s bounded
prepared-statement LRU) does what it's supposed to do on the write path.

**breezeorm is consistently the slowest library on reads** (FindByID,
SelectWhereLimit) — 1.5-2x slower than GORM/Bun/sqlx, confirmed reproducible
across 3 independent runs. This benchmark caught two real, fixable
architectural gaps, not a fundamental limitation:

1. **Fixed during this session**: `pkg/orm.Query[T].Find/Create/UpdateAll/
   Delete` were calling `compiler.Compile` — full `planner.Build`, the
   8-pass optimizer pipeline, and a SHA-256 structural hash — on *every
   single call*, even for a query shape executed a thousand times before.
   Only the downstream SQL-text and prepared-statement caches (in
   `Executor`) were actually warm on repeat calls. Added
   `DB.compiledCache` (`pkg/compiler/prehash.go` + `pkg/orm/query.go`'s
   `compileCached`), keyed on a cheap pre-optimization structural hash
   computed directly from the `query.Builder`. This measurably cut
   allocations (FindByID: 64→54 allocs/op; SelectWhereLimit: 612→600
   allocs/op — see `results_before_compiled_cache.txt` vs `results_raw.txt`)
   but did **not** close the wall-clock gap to GORM/Bun/sqlx — meaning the
   remaining overhead is elsewhere.

2. **Found, not yet fixed — the next concrete target**: `pkg/scanner.Compile`
   (which matches SQL result columns against compiled metadata to build a
   `scanner.Plan`) is called fresh on **every** `Find` call in
   `pkg/orm/query.go` — it isn't cached at all, unlike the metadata compiler
   it depends on. For a fixed query shape, the result column list is always
   the same, so the `Plan` it produces is always the same — this is
   identical in spirit to the `DB.compiledCache` fix above and should get a
   parallel fix: cache `*scanner.Plan` keyed by (table, ordered column list).
   Given `reflect.NewAt` is also called once per column per row inside
   `ScanRow`, the per-row decode path itself is the other place worth
   profiling before claiming "zero-reflection" is fully achieved end to end
   — right now that's true for the metadata compiler, not yet true for the
   scan path's plan construction.

Flagging both rather than shipping a benchmark that quietly looks better
than the code actually performs.

## Why GORM is slowest on Insert specifically

GORM's `Create` does the most per-call work of any library tested here —
hook dispatch, default-value population, and reflection-based field
extraction add up to 105 allocations/op, the highest of the five. This
tracks with GORM's known reputation for insert-path overhead relative to
its read-path performance.
