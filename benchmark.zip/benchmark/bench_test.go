// Package benchmark compares breezeorm against database/sql (raw, prepared —
// the fastest-possible baseline), GORM, Bun, and sqlx, on SQLite via the
// shared mattn/go-sqlite3 (cgo) driver. Run with:
//
//	go test -bench . -benchmem ./...
//
// See README.md in this directory for methodology notes and results.
package benchmark

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/nelthaarion/breezeorm/pkg/dialect"
	"github.com/nelthaarion/breezeorm/pkg/orm"
	"github.com/nelthaarion/breezeorm/pkg/query"

	"github.com/jmoiron/sqlx"
	"github.com/uptrace/bun"
	"github.com/uptrace/bun/dialect/sqlitedialect"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// --- per-library setup -----------------------------------------------------

func openbreezeorm(b *testing.B, dbFile string) (*orm.DB, func()) {
	sqlDB := rawOpen(b, dbFile)
	db := orm.Open(sqlDB, dialect.SQLite{})
	return db, func() { db.Close() }
}

func openGorm(b *testing.B, dbFile string) (*gorm.DB, func()) {
	raw := rawOpen(b, dbFile)
	raw.Close() // schema is applied; GORM opens its own connection below
	g, err := gorm.Open(sqlite.Open(dbFile), &gorm.Config{
		Logger:      logger.Default.LogMode(logger.Silent),
		PrepareStmt: true, // GORM's own statement cache — fair comparison against breezeorm's
	})
	if err != nil {
		b.Fatalf("gorm.Open: %v", err)
	}
	sqlDB, err := g.DB()
	if err != nil {
		b.Fatalf("gorm underlying DB: %v", err)
	}
	sqlDB.SetMaxOpenConns(1)
	return g, func() { sqlDB.Close() }
}

func openBun(b *testing.B, dbFile string) (*bun.DB, func()) {
	sqlDB := rawOpen(b, dbFile)
	bunDB := bun.NewDB(sqlDB, sqlitedialect.New())
	return bunDB, func() { bunDB.Close() }
}

func openSqlx(b *testing.B, dbFile string) (*sqlx.DB, func()) {
	sqlDB := rawOpen(b, dbFile)
	sdb := sqlx.NewDb(sqlDB, "sqlite3")
	return sdb, func() { sdb.Close() }
}

// --- Insert ------------------------------------------------------------

func BenchmarkInsert(b *testing.B) {
	b.Run("raw_sql_prepared", func(b *testing.B) {
		db := rawOpen(b, newSQLiteFile(b, "raw_insert"))
		defer db.Close()
		stmt, err := db.Prepare(`INSERT INTO bench_users (email, name, active, created_at) VALUES (?, ?, ?, ?)`)
		if err != nil {
			b.Fatal(err)
		}
		defer stmt.Close()
		now := time.Now().UTC()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			if _, err := stmt.Exec(fmt.Sprintf("ins%d@example.com", i), "Insert User", true, now); err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("breezeorm", func(b *testing.B) {
		db, cleanup := openbreezeorm(b, newSQLiteFile(b, "breezeorm_insert"))
		defer cleanup()
		ctx := context.Background()
		now := time.Now().UTC()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			u := BenchUser{Email: fmt.Sprintf("ins%d@example.com", i), Name: "Insert User", Active: true, CreatedAt: now}
			if err := orm.Model[BenchUser](db).Create(ctx, &u); err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("gorm", func(b *testing.B) {
		g, cleanup := openGorm(b, newSQLiteFile(b, "gorm_insert"))
		defer cleanup()
		now := time.Now().UTC()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			u := BenchUserGorm{Email: fmt.Sprintf("ins%d@example.com", i), Name: "Insert User", Active: true, CreatedAt: now}
			if err := g.Create(&u).Error; err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("bun", func(b *testing.B) {
		bunDB, cleanup := openBun(b, newSQLiteFile(b, "bun_insert"))
		defer cleanup()
		ctx := context.Background()
		now := time.Now().UTC()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			u := BenchUserBun{Email: fmt.Sprintf("ins%d@example.com", i), Name: "Insert User", Active: true, CreatedAt: now}
			if _, err := bunDB.NewInsert().Model(&u).Exec(ctx); err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("sqlx", func(b *testing.B) {
		sdb, cleanup := openSqlx(b, newSQLiteFile(b, "sqlx_insert"))
		defer cleanup()
		now := time.Now().UTC()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			_, err := sdb.Exec(`INSERT INTO bench_users (email, name, active, created_at) VALUES (?, ?, ?, ?)`,
				fmt.Sprintf("ins%d@example.com", i), "Insert User", true, now)
			if err != nil {
				b.Fatal(err)
			}
		}
	})
}

// --- FindByID ------------------------------------------------------------

func BenchmarkFindByID(b *testing.B) {
	b.Run("raw_sql_prepared", func(b *testing.B) {
		db := rawOpen(b, newSQLiteFile(b, "raw_find"))
		defer db.Close()
		seedRows(b, db, seedRowCount)
		stmt, err := db.Prepare(`SELECT id, email, name, active, created_at FROM bench_users WHERE id = ?`)
		if err != nil {
			b.Fatal(err)
		}
		defer stmt.Close()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			var u BenchUser
			row := stmt.QueryRow(id)
			if err := row.Scan(&u.ID, &u.Email, &u.Name, &u.Active, &u.CreatedAt); err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("breezeorm", func(b *testing.B) {
		db, cleanup := openbreezeorm(b, newSQLiteFile(b, "breezeorm_find"))
		defer cleanup()
		seedRows(b, db.SQLDB(), seedRowCount)
		ctx := context.Background()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			_, err := orm.Model[BenchUser](db).
				Where(query.Predicate{Column: "id", Op: query.OpEq, Value: id}).
				First(ctx)
			if err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("gorm", func(b *testing.B) {
		g, cleanup := openGorm(b, newSQLiteFile(b, "gorm_find"))
		defer cleanup()
		sqlDB, _ := g.DB()
		seedRows(b, sqlDB, seedRowCount)
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			var u BenchUserGorm
			if err := g.Where("id = ?", id).First(&u).Error; err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("bun", func(b *testing.B) {
		bunDB, cleanup := openBun(b, newSQLiteFile(b, "bun_find"))
		defer cleanup()
		seedRows(b, bunDB.DB, seedRowCount)
		ctx := context.Background()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			u := new(BenchUserBun)
			if err := bunDB.NewSelect().Model(u).Where("id = ?", id).Scan(ctx); err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("sqlx", func(b *testing.B) {
		sdb, cleanup := openSqlx(b, newSQLiteFile(b, "sqlx_find"))
		defer cleanup()
		seedRows(b, sdb.DB, seedRowCount)
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			var u BenchUser
			if err := sdb.Get(&u, "SELECT id, email, name, active, created_at FROM bench_users WHERE id = ?", id); err != nil {
				b.Fatal(err)
			}
		}
	})
}

// --- SelectWhereLimit (list query) ------------------------------------------

func BenchmarkSelectWhereLimit(b *testing.B) {
	b.Run("raw_sql_prepared", func(b *testing.B) {
		db := rawOpen(b, newSQLiteFile(b, "raw_select"))
		defer db.Close()
		seedRows(b, db, seedRowCount)
		stmt, err := db.Prepare(`SELECT id, email, name, active, created_at FROM bench_users WHERE active = ? ORDER BY id LIMIT 50`)
		if err != nil {
			b.Fatal(err)
		}
		defer stmt.Close()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			rows, err := stmt.Query(true)
			if err != nil {
				b.Fatal(err)
			}
			var out []BenchUser
			for rows.Next() {
				var u BenchUser
				if err := rows.Scan(&u.ID, &u.Email, &u.Name, &u.Active, &u.CreatedAt); err != nil {
					b.Fatal(err)
				}
				out = append(out, u)
			}
			rows.Close()
		}
	})

	b.Run("breezeorm", func(b *testing.B) {
		db, cleanup := openbreezeorm(b, newSQLiteFile(b, "breezeorm_select"))
		defer cleanup()
		seedRows(b, db.SQLDB(), seedRowCount)
		ctx := context.Background()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			_, err := orm.Model[BenchUser](db).
				Where(query.Predicate{Column: "active", Op: query.OpEq, Value: true}).
				OrderBy(query.OrderTerm{Column: "id"}).
				Limit(50).
				Find(ctx)
			if err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("gorm", func(b *testing.B) {
		g, cleanup := openGorm(b, newSQLiteFile(b, "gorm_select"))
		defer cleanup()
		sqlDB, _ := g.DB()
		seedRows(b, sqlDB, seedRowCount)
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			var us []BenchUserGorm
			if err := g.Where("active = ?", true).Order("id").Limit(50).Find(&us).Error; err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("bun", func(b *testing.B) {
		bunDB, cleanup := openBun(b, newSQLiteFile(b, "bun_select"))
		defer cleanup()
		seedRows(b, bunDB.DB, seedRowCount)
		ctx := context.Background()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			var us []BenchUserBun
			err := bunDB.NewSelect().Model(&us).Where("active = ?", true).OrderExpr("id").Limit(50).Scan(ctx)
			if err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("sqlx", func(b *testing.B) {
		sdb, cleanup := openSqlx(b, newSQLiteFile(b, "sqlx_select"))
		defer cleanup()
		seedRows(b, sdb.DB, seedRowCount)
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			var us []BenchUser
			err := sdb.Select(&us, "SELECT id, email, name, active, created_at FROM bench_users WHERE active = ? ORDER BY id LIMIT 50", true)
			if err != nil {
				b.Fatal(err)
			}
		}
	})
}

// --- Update ------------------------------------------------------------

func BenchmarkUpdate(b *testing.B) {
	b.Run("raw_sql_prepared", func(b *testing.B) {
		db := rawOpen(b, newSQLiteFile(b, "raw_update"))
		defer db.Close()
		seedRows(b, db, seedRowCount)
		stmt, err := db.Prepare(`UPDATE bench_users SET name = ? WHERE id = ?`)
		if err != nil {
			b.Fatal(err)
		}
		defer stmt.Close()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			if _, err := stmt.Exec("updated", id); err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("breezeorm", func(b *testing.B) {
		db, cleanup := openbreezeorm(b, newSQLiteFile(b, "breezeorm_update"))
		defer cleanup()
		seedRows(b, db.SQLDB(), seedRowCount)
		ctx := context.Background()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			_, err := orm.Model[BenchUser](db).
				Where(query.Predicate{Column: "id", Op: query.OpEq, Value: id}).
				UpdateAll(ctx, query.Assignment{Column: "name", Value: "updated"})
			if err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("gorm", func(b *testing.B) {
		g, cleanup := openGorm(b, newSQLiteFile(b, "gorm_update"))
		defer cleanup()
		sqlDB, _ := g.DB()
		seedRows(b, sqlDB, seedRowCount)
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			if err := g.Model(&BenchUserGorm{}).Where("id = ?", id).Update("name", "updated").Error; err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("bun", func(b *testing.B) {
		bunDB, cleanup := openBun(b, newSQLiteFile(b, "bun_update"))
		defer cleanup()
		seedRows(b, bunDB.DB, seedRowCount)
		ctx := context.Background()
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			_, err := bunDB.NewUpdate().Model(&BenchUserBun{Name: "updated"}).Column("name").Where("id = ?", id).Exec(ctx)
			if err != nil {
				b.Fatal(err)
			}
		}
	})

	b.Run("sqlx", func(b *testing.B) {
		sdb, cleanup := openSqlx(b, newSQLiteFile(b, "sqlx_update"))
		defer cleanup()
		seedRows(b, sdb.DB, seedRowCount)
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			id := int64(i%seedRowCount) + 1
			if _, err := sdb.Exec("UPDATE bench_users SET name = ? WHERE id = ?", "updated", id); err != nil {
				b.Fatal(err)
			}
		}
	})
}
